//=================
// mjpg-stream viwer javascript
// /js/mjpg_stream.js
// jquery.js を同時にインクルードして下さい。
//=================
// コール元で下記コマンドを実行してください。
// append these java script to html script line
/*
jq$= jQuery.noConflict();
jq$(function(){
  jq$.ajaxSetup({
    timeout:5000
  });
  startImageLayer("http://192.168.x.x:8080");
});
function re_load(){
  startImageLayer("http://192.168.x.x:8080");
}
*/

/* write this html-tag to html line
<div id="webcam" style="height:500px;"><noscript><img src="http://192.168.x.x:8080/?action=snapshot\" /></noscript></div>
*/



// active java script start
/* Copyright (C) 2007 Richard Atterer, richard©atterer.net
This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License, version 2. See the file
COPYING for details. */

var imageNr = 0; // Serial number of current image
var finished = new Array(); // References to img objects which have finished downloading
var paused = false;

var imageLayer_url;

function startImageLayer(url_s){
  imageLayer_url=url_s;
  createImageLayer();
}

function createImageLayer() {
  var img = new Image();
  img.style.position = "absolute";
  img.style.zIndex = -1;
  img.onload = imageOnload;
  img.onclick = imageOnclick;
  img.src = imageLayer_url+"/?action=snapshot&n=" + (++imageNr);
  var webcam = document.getElementById("webcam");
  webcam.insertBefore(img, webcam.firstChild);
}

// Two layers are always present (except at the very beginning), to avoid flicker
function imageOnload() {
  this.style.zIndex = imageNr; // Image finished, bring to front!
  while (1 < finished.length) {
    var del = finished.shift(); // Delete old image(s) from document
    del.parentNode.removeChild(del);
  }
  finished.push(this);
  if (!paused) createImageLayer();
}

function imageOnclick() { // Clicking on the image will pause the stream
  paused = !paused;
  if (!paused) createImageLayer();
}

