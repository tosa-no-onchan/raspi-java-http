//=================
// /js/raspi-netosa-jquery.js
// jquery.js を同時にインクルードして下さい。
//=================


// コール元で下記コマンドを実行してください。
/*
jq$= jQuery.noConflict();
jq$(function(){
  jq$.ajaxSetup({
    timeout:5000
  });
  reqCart_list('005');
});
*/

//タイムアウト
function errorFunc(xmlHttp){
  alert("タイムアウトエラーです!!");
}

//Ajax リクエスト処理
function reqAjax(url,req_s){
  var date_now = new Date();

  //alert("reqAjax() : #1 passed!! url="+url+",req_s="+req_s);

  httpObj = jq$.get(url,{begin:"1",func:"ajax",ajax_req:req_s,date_stump:date_now},checkReqAjax,"xml");

  //httpObj = jq$.get("/cgi-bin/netosa/cart/user/cart_entry.cgi",{tno:tno_req,xml_req:"1",func:"check_out",date_stump:date_now},checkCart_list,"xml");
}

//Ajax リクエストの受信ディスパッチャー
function checkReqAjax(){
  //alert("checkReqAjax() : called httpObj="+httpObj);
  var res = httpObj.responseXML;
  var msg = res.getElementsByTagName("msg");
  var msg_s = msg[0].firstChild.nodeValue;
  var reload_req = res.getElementsByTagName("reload_req");
  var reload_req_s = reload_req[0].firstChild.nodeValue;
  //alert("checkReqAjax() : #2 msg_s="+msg_s);
  //alert("checkReqAjax() : #3 reload_req_s="+reload_req_s);

  if(reload_req_s != null && reload_req_s == "yes"){
    re_load();
  }
  jq$("#ans_msg").text(msg_s);
}

