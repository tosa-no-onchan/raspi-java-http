<form action="<?php echo $_SERVER['SCRIPT_NAME'] ?>" method="post">
  <input type="text" name="num1" size="4"> +
  <input type="text" name="num2" size="4">
  <input type="submit" value=" = ">
</form>
<?php
echo "--------<br />\n"; 
var_dump($_POST);
echo "<br />--------<br />\n"; 

if ($_POST) {
  $num1 = $_POST['num1'];
  $num2 = $_POST['num2'];
  echo $num1, ' + ', $num2, ' = ', $num1 + $num2;
}

echo "<br />--------<br />\n"; 

foreach($_SERVER as $key => $val)
{
        echo "${key} : ${val}<br>\n";
}

?>