<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<p>hello.php called</p>'; ?>
<?php
// not work
echo $_GET["parm"];
echo "<br />\n";

// get parameters
$str = $_SERVER["QUERY_STRING"];
$list=split("&", $str);
foreach($list as $rec){
  list($key,$val)=split("=",$rec);
  echo "${key} -> ${val}<br />\n";
}
echo "<br />\n";

foreach($_SERVER as $key => $val)
{
        echo "${key} : ${val}<br>\n";
}
?>
 </body>
</html>